#include "GWS_5.h"
#include "OPERATING_SYSTE.h"
#include "GHGLTGGAMER.h"
#include "GHGLTGGAMER_API_INSTALLER.h"


#define GWS_5_CONTROLLS
#define GWS_CONTROLLS
#define OPERATINGSYSTE
#define GHGLTGGAMER_LIB

int window(){
	GTG_WINDOW* Window = Create(Window(100, 100, "GWS_5", GTG_INIT_GWS_DATA));
	Window.Create_new(true);
	
	CPP_CONVEX_INT_CALL();
	
	BROWSE("GWS_5_ASSETS");
	LAUNCH(ON_WINDOW_CREATED, BROWSE(AUTO));
}